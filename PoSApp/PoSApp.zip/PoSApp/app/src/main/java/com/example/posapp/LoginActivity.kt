package com.example.posapp

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.PersistableBundle
import android.util.Log
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import org.w3c.dom.Text

class LoginActivity : AppCompatActivity() {
    private val TAG= "LoginActivity"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        val secretText = findViewById<TextView>(R.id.TitleTextView)
        secretText.setOnLongClickListener {
            val intent = Intent(this,PosSettings::class.java)
            startActivity(intent)
            true
        }



    }


    fun clickLogin (view: View){
        val username = findViewById<EditText>(R.id.input_user)
        Toast.makeText(this,"${username.text} just clicked me ",Toast.LENGTH_SHORT).show()
        val intent = Intent(this,CategoryActivity::class.java)
        startActivity(intent)
    }



}