package com.example.posapp

class Drink(DrinkName: String,DrinkPrice:String,DrinkID:Int):Product() {
    override val id: Int=DrinkID
    override val name:String=DrinkName
    override val price:String=DrinkPrice

    companion object{
        fun createDrinkList():ArrayList<Product>{
            val drinkList = ArrayList<Product>()
            drinkList.add(Drink("Soft drinks","10.0",1001))
            drinkList.add(Drink("Water","7.0",1002))
            drinkList.add(Drink("Coffee","15.0",1003))
            drinkList.add(Drink("Liquor","40.0",1004))
            return drinkList
        }
    }
}