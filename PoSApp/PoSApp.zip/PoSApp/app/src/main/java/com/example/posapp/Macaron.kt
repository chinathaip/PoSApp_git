package com.example.posapp

class Macaron(MacaronName : String,MacaronPrice : String,MacaronID: Int): Product() {
    override val id: Int = MacaronID
    override val name: String = MacaronName
    override val price:String = MacaronPrice

   companion object{
       //with companion keyword, an object will be initialized as soon as its containing class is loaded, even though it's not gonna be used
       //without this keyword, object initialization is lazy, meaning that an object will not be created unless it will be used.


        fun createMacaronList():ArrayList<Product>{
            val listofMacaron = ArrayList<Product>()
            listofMacaron.add(Macaron("Black Macaron","15.0",1001))
            listofMacaron.add(Macaron("Blue Macaron","13.0",1002))
            listofMacaron.add(Macaron("Green Macaron","16.0",1003))
            listofMacaron.add(Macaron("Navy Macaron","17.0",1004))
            listofMacaron.add(Macaron("Pink Macaron","12.0",1005))
            listofMacaron.add(Macaron("Red Macaron","11.0",1006))
            listofMacaron.add(Macaron("Yellow Macaron","14.0",1007))
            return listofMacaron
        }


        /* refer to OrderActivity.kt
       we were able to call "Macaron.createMacaronList()" right away without having to mention which object we're talking about
       without companion keyword, we need to give a name to an object and refer to it before using the function inside.
       --------------------------------
       object XD{
            fun createXD()
       }
       > Macaron.XD.createXD()
       --------------------------------
       companion object{
            fun createXD()
       }
       > Macaron.createXD()  / Macaron.companion.createXD()
       --------------------------------
        */
    }



}