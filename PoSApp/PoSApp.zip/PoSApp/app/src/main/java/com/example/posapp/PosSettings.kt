package com.example.posapp

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.FileProvider
import java.io.File
import java.net.URI

class PosSettings : AppCompatActivity() {
    private var imageUri : Uri?=null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pos_settings)
        val takePic = registerForActivityResult(ActivityResultContracts.TakePicture()){ isSuccess ->
            /*
                ActivityResultContracts.TakePicture() takes a picture and save to the provided Uri
                if the image is saved successfully, the function will return "true"
                "isSuccess" is the returned value from .TakePicture()
                 */
            if(isSuccess){// if the picture was taken and saved successfully.. (this is basically "if (true)"
                //create an alert box. after clicking "yes", the image will be put into the layout
                val alertdialog = AlertDialog.Builder(this)
                alertdialog.setTitle("Upload picture status")
                alertdialog.setMessage("Successfully uploaded")
                alertdialog.setPositiveButton("Yes"){
                        dialog,which -> Toast.makeText(this,"Yes",Toast.LENGTH_SHORT).show()
                    val conStraintLayout = findViewById<ConstraintLayout>(R.id.lol)
                    val factor:Float = conStraintLayout.context.resources.displayMetrics.density
                    Log.i("SettingActivity", factor.toString())
                    val width = conStraintLayout.width * 0.5 *factor
                    val height = conStraintLayout.height*0.3 * factor

                    val imageView = ImageView(this)
                    imageView.layoutParams=ConstraintLayout.LayoutParams(width.toInt(),height.toInt())
                    imageView.setImageURI(imageUri) //use the value saved in the code below
                    conStraintLayout.addView(imageView)
                }
                alertdialog.show()


            }else{// if the picture wasn't taken or saved successfully.....
                //create an alert box. after clicking ok, nothing happens lol
                val alertdialog = AlertDialog.Builder(this)
                alertdialog.setTitle("Upload picture status")
                alertdialog.setMessage("Upload Failed")
                alertdialog.setNegativeButton("OK"){
                        dialong,which ->Toast.makeText(this,"OK",Toast.LENGTH_SHORT).show()
                }
                alertdialog.show()
            }
        }
        val uploaddailyBtn = findViewById<Button>(R.id.uploadDailyBTN)
        uploaddailyBtn.setOnClickListener{
            val imagePath = File(getExternalFilesDir(null),"my_images") //create a new File instance from parent pathname and child pathname
            imagePath.mkdirs() //create the directory from the given parameter above^^^^
            val newFile=File(imagePath,"img_${System.currentTimeMillis()}.jpg") // create a new jpg file using the path from imagePath, each file is named according to the time of creation
            val imgUri :Uri= FileProvider.getUriForFile(this,"com.example.posapp.fileprovider",newFile) //generate a new URI
            this.imageUri=imgUri //not related to the code, just save the value so we can use it in the callback
            takePic.launch(imgUri)  //call ActivityResultLauncher and pass the generated URI to it
        }

        val searchContactBtn = findViewById<Button>(R.id.searchcontactBtn)
        searchContactBtn.setOnClickListener{
            Toast.makeText(this,"Going to the search contact page",Toast.LENGTH_SHORT).show()
            val intent = Intent(this,SearchContactActivity::class.java)
            startActivity(intent)
        }
    }
}