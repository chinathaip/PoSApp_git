package com.example.posapp

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import kotlin.collections.ArrayList

class RecyclerViewAdapter(private val itemList: ArrayList<Product>):RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder>(){
    class ViewHolder(ListitemView: View):RecyclerView.ViewHolder(ListitemView) {
        val productImageView: ImageView = ListitemView.findViewById(R.id.productimageView)
        val productNameTextView: TextView = ListitemView.findViewById(R.id.NameView)
        val productPriceTextView: TextView = ListitemView.findViewById(R.id.PriceView)
    }

    //this function creates a new ViewHolder(item inside a recyclerview) frame for inputting data
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {

        val context = parent.context
        val MacaronView = LayoutInflater.from(context).inflate(R.layout.order_layout,parent,false)
    // take in XML file as an input and builds a View object from it.  ".from" means get the XML from the given context?
        return ViewHolder(MacaronView)
    }

    //this function puts data inside the viewholder created by "onCreateViewHolder"
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = itemList[position]
        /*
        macaronList is an arraylist of Macaron.kt object (refer to Macaron.kt)

       index 0 = ["Black Macaron","15.0",1001]
       index 1 = ["Blue Macaron","13.0",1002]
       index 2 = ["Green Macaron","16.0",1003] and so on

       This means that "macaron" is containing all those ["black","15.0",1001] depending on which index(position) it is.
       position is gathered from the linearlayout manager (refer OrderActivity.kt)
         */
//        Log.i("xD", OrderActivity.catID.toString())
        when(OrderActivity.catID){
            MACARON_CAT_ID->{
                when(position){
                    /*we use "when" keyword because there's no data about the macaron image inside "macaronList" (refer to the comment above)
                    This means that the image will not change as "position"/index changes, so we have to do it manually.
                    "when" is basically "switch" in Java
                     */
                    0-> holder.productImageView.setImageResource(R.drawable.macaron_black)
                    1-> holder.productImageView.setImageResource(R.drawable.macaron_blue)
                    2-> holder.productImageView.setImageResource(R.drawable.macaron_green)
                    3-> holder.productImageView.setImageResource(R.drawable.macaron_navy)
                    4-> holder.productImageView.setImageResource(R.drawable.macaron_pink)
                    5-> holder.productImageView.setImageResource(R.drawable.macaron_red)
                    6-> holder.productImageView.setImageResource(R.drawable.macaron_yellow)
                    else-> holder.productImageView.setImageResource(R.drawable.macaron_black)
                }
            }
            DRINK_CAT_ID->{
                when(position){
                    0->holder.productImageView.setImageResource(R.drawable.drink_softdrink)
                    2->holder.productImageView.setImageResource(R.drawable.drink_coffee)
                    else->holder.productImageView.setImageResource(R.drawable.drink_softdrink)
                }
            }

        }


        holder.productNameTextView.setText(item.name)
        holder.productPriceTextView.setText(item.price)
        /*
        since "macaron" contains a Macaron.kt object, it can access the variable inside (refer to Macaron.kt)
        we change the image, name , and the price of the macaron depending on the "position"
         */

    }

    override fun getItemCount(): Int {
        return itemList.size
    }
}