package com.example.posapp

open class Product(){
    open val id : Int = 0
    open val name : String = "product name"
    open val price : String = "0"


}