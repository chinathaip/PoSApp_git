package com.example.posapp
const val MACARON_CAT_ID=1000
const val DRINK_CAT_ID=2000
