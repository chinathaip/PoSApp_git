package com.example.posapp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView


class ListViewAdapter(private val listofItem:ArrayList<Macaron>): BaseAdapter() {
    override fun getCount(): Int {
        return listofItem.size
    }

    override fun getItem(position: Int): Any {
        return listofItem[position]
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val rowView = LayoutInflater.from(parent?.context).inflate(R.layout.order_layout,parent,false)
        val productImageView : ImageView = rowView.findViewById(R.id.productimageView)
        val productNameTextView : TextView = rowView.findViewById(R.id.NameView)
        val productPriceTextView : TextView = rowView.findViewById(R.id.PriceView)
        when(position){

            0-> productImageView.setImageResource(R.drawable.macaron_black)
            1-> productImageView.setImageResource(R.drawable.macaron_blue)
            2-> productImageView.setImageResource(R.drawable.macaron_green)
            3-> productImageView.setImageResource(R.drawable.macaron_navy)
            4-> productImageView.setImageResource(R.drawable.macaron_pink)
            5-> productImageView.setImageResource(R.drawable.macaron_red)
            6-> productImageView.setImageResource(R.drawable.macaron_yellow)
            else-> productImageView.setImageResource(R.drawable.macaron_black)
        }
        val macaron = listofItem[position]

        productNameTextView.text=macaron.name
        productPriceTextView.text=macaron.price
        return rowView
    }
}