package com.example.posapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class OrderActivity : AppCompatActivity() {

    //i created a companion object to make a static variable, one that can be accessed by any class
    //so that RecylclerViewAdapter.kt can just type "OrderActivity.catID" to get the value
    companion object{
        var catID:Int?=null
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_order)
        val recyclerview = findViewById<RecyclerView>(R.id.productLIst)
        catID = intent.getIntExtra("CatID",0)
        //retrieve the data of Category ID by entering the keyword that 'stores' the data we 'putExtra' to.  (CatID in this case) (refer to CategoryActivity)
        Log.i("lol", catID.toString())
        recyclerview.layoutManager=LinearLayoutManager(this)

        when(catID){
            MACARON_CAT_ID->{
                val macaron = Macaron.createMacaronList()
                val macaronAdapter= RecyclerViewAdapter(macaron)
                recyclerview.adapter=macaronAdapter

            }
            DRINK_CAT_ID->{
                val drink = Drink.createDrinkList()
                val drinkAdapter = RecyclerViewAdapter(drink)
                recyclerview.adapter=drinkAdapter

            }
        }

//        val listview = findViewById<ListView>(R.id.productListView)
//        val adapter2 =ListViewAdapter(macaron)
//        listview.adapter=adapter2

    }


}