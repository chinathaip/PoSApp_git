package com.example.posapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import com.example.posapp.databinding.ActivitySearchContactBinding



class SearchContactActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySearchContactBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        binding = ActivitySearchContactBinding.inflate(layoutInflater)
//        val view = binding.root
        setContentView(R.layout.activity_search_contact)
    }


}